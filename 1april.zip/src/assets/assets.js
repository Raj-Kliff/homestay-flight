import flight from './flight.jpg'
import flightFailure from './failure-icon.png'

export const flight_assets = {
    flight,
    flightFailure
}

