import React, { useState } from 'react';
import { CircleUserRound, BadgeIndianRupee, Ticket, Users } from 'lucide-react';

const StatCard = ({ title, value, icon, color }) => (
  <div className={`bg-${color}-100 p-4 rounded-lg shadow-md flex items-center space-x-4`}>
    <div className={`p-4 bg-${color}-500 text-white rounded-full`}>
      {icon}
    </div>
    <div>
      <h2 className="text-xl font-semibold">{title}</h2>
      <p className="text-gray-500">{value}</p>
    </div>
  </div>
);

function Dashboard() {

  const [data, setData] = useState({
    totalSales: 1245,
    activeUsers: 325,
    supportTickets: 45,
    newCustomers: 67,
  });

  return (
    <div className="bg-white rounded-lg shadow-sm p-6 mt-5">
      <h1 className="text-2xl font-semibold text-gray-800 mb-4">Welcome to Dashboard</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
        <StatCard
          title="Total Sales"
          value={`Rs ${data.totalSales}`}
          icon={<BadgeIndianRupee className="w-5 h-5" />}
          color="blue"
        />
        <StatCard
          title="Active Users"
          value={data.activeUsers}
          icon={<CircleUserRound className="w-5 h-5" />}
          color="red"
        />
        <StatCard
          title="Support Tickets"
          value={data.supportTickets}
          icon={<Ticket className="w-5 h-5" />}
          color="blue"
        />
        <StatCard
          title="New Customers"
          value={data.newCustomers}
          icon={<Users className="w-5 h-5" />}
          color="purple"
        />
      </div>
    </div>
  );
}

export default Dashboard;